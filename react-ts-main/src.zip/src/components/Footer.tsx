import "./css.css"

const Footer = () => {
    return (
        <div className="container">
            <div className="footer">
                <h2>Phạm Thị Ngọc Thảo</h2>
            </div>
        </div>
    )
}

export default Footer;