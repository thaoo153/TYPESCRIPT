import React from 'react';
import { Header, Footer } from '../components';
import "../components/css.css";
import { products } from '../sample-data/product';

const HomePage = () => {
    return (
        <div>
            <Header />
            <div className='container'>
                <h1 className='center'>Product</h1>
                <div className="box">
                    {
                        products.map((value, index) => (
                            <div className='product' key={index}>
                                <p>{value.name}</p>
                                <img src={value.img} alt="" />
                                <div className='price'>
                                    <span>{value.price}đ</span><del>{value.price}đ</del>
                                </div>
                            </div>
                        ))
                    }
                </div>
            </div>
            <Footer />
        </div>
    );
}

export default HomePage;

